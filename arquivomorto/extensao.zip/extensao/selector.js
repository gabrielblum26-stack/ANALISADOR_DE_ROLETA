(function() {
  if (document.getElementById('extrator-overlay')) return;
  
  let startX, startY, isSelecting = false;
  
  const overlay = document.createElement('div');
  overlay.id = 'extrator-overlay';
  overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.3);cursor:crosshair;z-index:999999;';
  
  const selection = document.createElement('div');
  selection.style.cssText = 'position:fixed;border:3px solid #667eea;background:rgba(102,126,234,0.2);z-index:1000000;display:none;pointer-events:none;';
  
  const instruction = document.createElement('div');
  instruction.style.cssText = 'position:fixed;top:20px;left:50%;transform:translateX(-50%);background:#667eea;color:white;padding:12px 24px;border-radius:8px;font-family:Arial;font-size:14px;z-index:1000001;';
  instruction.textContent = '✂️ Arraste para selecionar a tabela. ESC para cancelar.';
  
  document.body.appendChild(overlay);
  document.body.appendChild(selection);
  document.body.appendChild(instruction);
  
  function cleanup() {
    overlay.remove();
    selection.remove();
    instruction.remove();
  }
  
  overlay.onmousedown = (e) => {
    isSelecting = true;
    startX = e.clientX;
    startY = e.clientY;
    selection.style.left = startX + 'px';
    selection.style.top = startY + 'px';
    selection.style.width = '0';
    selection.style.height = '0';
    selection.style.display = 'block';
  };
  
  overlay.onmousemove = (e) => {
    if (!isSelecting) return;
    const left = Math.min(startX, e.clientX);
    const top = Math.min(startY, e.clientY);
    const width = Math.abs(e.clientX - startX);
    const height = Math.abs(e.clientY - startY);
    selection.style.left = left + 'px';
    selection.style.top = top + 'px';
    selection.style.width = width + 'px';
    selection.style.height = height + 'px';
  };
  
  overlay.onmouseup = async (e) => {
    if (!isSelecting) return;
    isSelecting = false;
    
    const rect = {
      x: parseInt(selection.style.left),
      y: parseInt(selection.style.top),
      width: parseInt(selection.style.width),
      height: parseInt(selection.style.height)
    };
    
    if (rect.width < 20 || rect.height < 20) {
      cleanup();
      return;
    }
    
    cleanup();
    
    const loadingDiv = document.createElement('div');
    loadingDiv.id = 'extrator-loading';
    loadingDiv.style.cssText = 'position:fixed;top:20px;right:20px;background:#667eea;color:white;padding:12px 24px;border-radius:8px;font-family:Arial;font-size:14px;z-index:1000001;';
    loadingDiv.textContent = '⏳ Capturando...';
    document.body.appendChild(loadingDiv);
    
    // Salvar coordenadas para o background script
    window.extratorRect = rect;
    
    // Usar screenshot já capturada
    if (window.extratorScreenshot) {
      loadingDiv.textContent = '⏳ Processando OCR...';
      await processScreenshot(window.extratorScreenshot, rect, loadingDiv);
    } else {
      loadingDiv.remove();
      alert('Erro: Screenshot não encontrada. Tente novamente.');
    }
  };
  
  document.onkeydown = (e) => {
    if (e.key === 'Escape') cleanup();
  };
  
  async function processScreenshot(screenshot, rect, loadingDiv) {
    try {
      const img = new Image();
      img.onload = async () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const scale = window.devicePixelRatio || 1;
        
        canvas.width = rect.width * scale;
        canvas.height = rect.height * scale;
        
        ctx.drawImage(
          img,
          rect.x * scale, rect.y * scale,
          rect.width * scale, rect.height * scale,
          0, 0,
          canvas.width, canvas.height
        );
        
        // Aumentar escala para melhor OCR
        const canvas2 = document.createElement('canvas');
        const ctx2 = canvas2.getContext('2d');
        canvas2.width = canvas.width * 2;
        canvas2.height = canvas.height * 2;
        ctx2.drawImage(canvas, 0, 0, canvas2.width, canvas2.height);
        
        // Realçar o zero verde - converter verde/cyan para branco brilhante
        const imgData = ctx2.getImageData(0, 0, canvas2.width, canvas2.height);
        const data = imgData.data;
        
        for (let i = 0; i < data.length; i += 4) {
          const r = data[i], g = data[i+1], b = data[i+2];
          
          // Detectar verde/cyan (o zero) - mais amplo
          const isGreen = g > 60 && (g > r || b > r);
          const isCyan = g > 50 && b > 50 && r < 100;
          const isGreenish = (g - r) > 20 || (b - r) > 20;
          
          if (isGreen || isCyan || isGreenish) {
            // Converter para branco brilhante
            data[i] = 255;
            data[i+1] = 255;
            data[i+2] = 255;
          }
        }
        ctx2.putImageData(imgData, 0, 0);
        
        canvas2.toBlob(async (blob) => {
          const fd = new FormData();
          fd.append('file', blob, 'crop.png');
          fd.append('apikey', 'K85622838788957');
          fd.append('language', 'eng');
          fd.append('isTable', 'true');
          fd.append('scale', 'true');
          fd.append('OCREngine', '2');
          
          const response = await fetch('https://api.ocr.space/parse/image', {
            method: 'POST',
            body: fd
          });
          
          loadingDiv.remove();
          
          const result = await response.json();
          let numbers = [];
          
          if (result.ParsedResults && result.ParsedResults[0]) {
            // Pegar apenas números de 1-2 dígitos (0-36 da roleta)
            numbers = result.ParsedResults[0].ParsedText.match(/\b\d{1,2}\b/g) || [];
          }
          
          showPopup(numbers);
        }, 'image/png');
      };
      img.src = screenshot;
    } catch (err) {
      loadingDiv.remove();
      alert('Erro: ' + err.message);
    }
  }
  
  function showPopup(numbers) {
    const existing = document.getElementById('extrator-popup');
    if (existing) existing.remove();
    
    const popup = document.createElement('div');
    popup.id = 'extrator-popup';
    popup.style.cssText = 'position:fixed;top:20px;right:20px;background:linear-gradient(135deg,#1a1a2e,#16213e);border:2px solid #667eea;border-radius:12px;padding:20px;z-index:1000000;font-family:Arial;color:white;max-width:350px;max-height:400px;overflow-y:auto;box-shadow:0 10px 40px rgba(0,0,0,0.5);';
    
    popup.innerHTML = `
      <h3 style="color:#667eea;margin:0 0 15px 0;">🔢 Números (${numbers.length})</h3>
      <div style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:15px;">
        ${numbers.map(n => `<span style="background:linear-gradient(135deg,#667eea,#764ba2);padding:4px 10px;border-radius:6px;font-weight:bold;">${n}</span>`).join('')}
      </div>
      <div style="background:#0d0d1a;padding:10px;border-radius:8px;margin-bottom:15px;font-family:monospace;word-break:break-all;font-size:12px;">
        ${numbers.join(' ')}
      </div>
      <button id="extCopyBtn" style="background:linear-gradient(135deg,#00c853,#00e676);color:white;border:none;padding:12px;border-radius:8px;width:100%;font-weight:bold;cursor:pointer;margin-bottom:8px;">📋 Copiar</button>
      <button id="extCloseBtn" style="background:#333;color:white;border:none;padding:10px;border-radius:8px;width:100%;cursor:pointer;">✖ Fechar</button>
    `;
    
    document.body.appendChild(popup);
    
    document.getElementById('extCopyBtn').onclick = () => {
      navigator.clipboard.writeText(numbers.join(' '));
      document.getElementById('extCopyBtn').textContent = '✅ Copiado!';
    };
    
    document.getElementById('extCloseBtn').onclick = () => popup.remove();
  }
})();
