document.addEventListener('DOMContentLoaded', () => {
  const extractAllBtn = document.getElementById('extractAllBtn');
  const extractRecentBtn = document.getElementById('extractRecentBtn');
  const extractStatsBtn = document.getElementById('extractStatsBtn');
  const loading = document.getElementById('loading');
  const results = document.getElementById('results');
  const numbersGrid = document.getElementById('numbersGrid');
  const sequence = document.getElementById('sequence');
  const countSpan = document.getElementById('count');
  const copyBtn = document.getElementById('copyBtn');
  const copyStatus = document.getElementById('copyStatus');
  const errorDiv = document.getElementById('error');
  
  let extractedNumbers = [];

  // Seletores Evolution Gaming
  const EVOLUTION_SELECTORS = {
    recentNumbers: '[data-role="recent-number"] span[class^="value"]',
    statistics: '[data-role="statistics"] span[class^="value"]',
    numberByRole: '[data-role^="number-"]'
  };

  // Função de extração via executeScript
  async function extractNumbers(type = 'all') {
    try {
      hideAll();
      loading.classList.remove('hidden');
      
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      const result = await chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        func: (extractType) => {
          const SELECTORS = {
            recentNumbers: '[data-role="recent-number"] span[class^="value"]',
            statistics: '[data-role="statistics"] span[class^="value"]',
            numberByRole: '[data-role^="number-"]'
          };
          
          let numbers = [];
          
          // Números recentes
          if (extractType === 'recent' || extractType === 'all') {
            document.querySelectorAll(SELECTORS.recentNumbers).forEach(el => {
              const num = el.textContent.trim();
              if (num !== '' && !isNaN(num)) numbers.push(num);
            });
          }
          
          // Estatísticas/Histórico
          if (extractType === 'statistics' || extractType === 'all') {
            document.querySelectorAll(SELECTORS.statistics).forEach(el => {
              const num = el.textContent.trim();
              if (num !== '' && !isNaN(num)) numbers.push(num);
            });
          }
          
          // Fallback: data-role
          if (numbers.length === 0) {
            document.querySelectorAll(SELECTORS.numberByRole).forEach(el => {
              const role = el.getAttribute('data-role');
              if (role && role.startsWith('number-')) {
                const num = role.replace('number-', '');
                if (!isNaN(num)) numbers.push(num);
              }
            });
          }
          
          return numbers;
        },
        args: [type]
      });
      
      // Combinar resultados de todos os frames
      let numbers = [];
      for (const frame of result) {
        if (frame.result && frame.result.length > 0) {
          numbers = [...numbers, ...frame.result];
        }
      }
      
      if (numbers.length > 0) {
        extractedNumbers = numbers;
        displayResults(numbers);
      } else {
        showError('Nenhum número encontrado. Abra uma roleta Evolution Gaming.');
      }
    } catch (err) {
      showError('Erro: ' + err.message);
    } finally {
      loading.classList.add('hidden');
    }
  }

  // Event listeners
  extractAllBtn.addEventListener('click', () => extractNumbers('all'));
  extractRecentBtn.addEventListener('click', () => extractNumbers('recent'));
  extractStatsBtn.addEventListener('click', () => extractNumbers('statistics'));

  copyBtn.addEventListener('click', () => {
    const text = extractedNumbers.join(' ');
    navigator.clipboard.writeText(text);
    copyBtn.textContent = '✅ Copiado!';
    copyStatus.classList.remove('hidden');
    setTimeout(() => {
      copyBtn.textContent = '📋 Copiar';
      copyStatus.classList.add('hidden');
    }, 2000);
  });

  function displayResults(numbers) {
    const displayNums = numbers.slice(0, 50);
    numbersGrid.innerHTML = displayNums.map(n => 
      `<span class="number-item">${n}</span>`
    ).join('') + (numbers.length > 50 ? `<span class="number-more">+${numbers.length - 50}</span>` : '');
    
    sequence.textContent = numbers.join(' ');
    countSpan.textContent = numbers.length;
    results.classList.remove('hidden');
  }

  function showError(msg) {
    errorDiv.textContent = msg;
    errorDiv.classList.remove('hidden');
  }

  function hideAll() {
    loading.classList.add('hidden');
    results.classList.add('hidden');
    errorDiv.classList.add('hidden');
    copyStatus.classList.add('hidden');
  }
});
