chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'captureForCrop') {
    chrome.tabs.captureVisibleTab(null, { format: 'png' }, (screenshot) => {
      sendResponse({ screenshot: screenshot });
    });
    return true;
  }
});
