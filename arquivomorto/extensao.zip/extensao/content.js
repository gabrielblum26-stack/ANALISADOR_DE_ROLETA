// Extrator de Números - Evolution Gaming
// Lê diretamente do DOM sem precisar de OCR

// Seletores para Evolution Gaming
const EVOLUTION_SELECTORS = {
  // Números recentes (barra superior)
  recentNumbers: '[data-role="recent-number"] span[class^="value"]',
  // Estatísticas completas (histórico)
  statistics: '[data-role="statistics"] span[class^="value"]',
  // Alternativo: pegar pelo data-role do número
  numberByRole: '[data-role^="number-"]',
  // Container dos números recentes
  recentContainer: '.recentNumbers--141d3, [class*="recentNumbers"]',
  // Container das estatísticas
  statsContainer: '[data-role="statistics"]'
};

// Extrai números do DOM da Evolution
function extractEvolutionNumbers(type = 'all') {
  let numbers = [];
  
  try {
    if (type === 'recent' || type === 'all') {
      // Números recentes (barra superior)
      const recentElements = document.querySelectorAll(EVOLUTION_SELECTORS.recentNumbers);
      recentElements.forEach(el => {
        const num = el.textContent.trim();
        if (num !== '' && !isNaN(num)) {
          numbers.push(num);
        }
      });
    }
    
    if (type === 'statistics' || type === 'all') {
      // Estatísticas completas
      const statsElements = document.querySelectorAll(EVOLUTION_SELECTORS.statistics);
      statsElements.forEach(el => {
        const num = el.textContent.trim();
        if (num !== '' && !isNaN(num)) {
          numbers.push(num);
        }
      });
    }
    
    // Fallback: tentar pelo atributo data-role
    if (numbers.length === 0) {
      const allNumbers = document.querySelectorAll(EVOLUTION_SELECTORS.numberByRole);
      allNumbers.forEach(el => {
        const role = el.getAttribute('data-role');
        if (role && role.startsWith('number-')) {
          const num = role.replace('number-', '');
          if (!isNaN(num)) {
            numbers.push(num);
          }
        }
      });
    }
  } catch (error) {
    console.error('Erro ao extrair números:', error);
  }
  
  return numbers;
}

// Detecta se está em um iframe da Evolution
function findEvolutionFrame() {
  // Tenta no documento principal
  let numbers = extractEvolutionNumbers();
  if (numbers.length > 0) return { numbers, frame: 'main' };
  
  // Tenta em iframes
  const iframes = document.querySelectorAll('iframe');
  for (let iframe of iframes) {
    try {
      const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
      const recentElements = iframeDoc.querySelectorAll(EVOLUTION_SELECTORS.recentNumbers);
      if (recentElements.length > 0) {
        let nums = [];
        recentElements.forEach(el => {
          const num = el.textContent.trim();
          if (num !== '' && !isNaN(num)) nums.push(num);
        });
        if (nums.length > 0) return { numbers: nums, frame: 'iframe' };
      }
    } catch (e) {
      // CORS - não consegue acessar o iframe
    }
  }
  
  return { numbers: [], frame: null };
}

// Listener de mensagens
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extractEvolution') {
    const type = request.type || 'all';
    const result = findEvolutionFrame();
    
    if (result.numbers.length > 0) {
      showResultPopup(result.numbers, type);
      sendResponse({ success: true, numbers: result.numbers, source: result.frame });
    } else {
      showErrorPopup('Nenhum número encontrado. Verifique se está na página da roleta Evolution.');
      sendResponse({ success: false, error: 'Números não encontrados' });
    }
    return true;
  }
  
  if (request.action === 'extractRecent') {
    const numbers = extractEvolutionNumbers('recent');
    if (numbers.length > 0) {
      showResultPopup(numbers, 'recent');
      sendResponse({ success: true, numbers });
    } else {
      showErrorPopup('Números recentes não encontrados.');
      sendResponse({ success: false });
    }
    return true;
  }
  
  if (request.action === 'extractStatistics') {
    const numbers = extractEvolutionNumbers('statistics');
    if (numbers.length > 0) {
      showResultPopup(numbers, 'statistics');
      sendResponse({ success: true, numbers });
    } else {
      showErrorPopup('Estatísticas não encontradas.');
      sendResponse({ success: false });
    }
    return true;
  }
});

// Remove popups anteriores
function removeExistingPopups() {
  document.querySelectorAll('#extrator-popup, #extrator-error').forEach(el => el.remove());
}

// Popup de resultado
function showResultPopup(numbers, type = 'all') {
  removeExistingPopups();
  
  const typeLabel = type === 'recent' ? 'Recentes' : type === 'statistics' ? 'Histórico' : 'Todos';
  
  const popup = document.createElement('div');
  popup.id = 'extrator-popup';
  popup.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    border: 2px solid #00c853;
    border-radius: 12px;
    padding: 20px;
    z-index: 1000000;
    font-family: Arial, sans-serif;
    color: white;
    max-width: 400px;
    max-height: 500px;
    overflow-y: auto;
    box-shadow: 0 10px 40px rgba(0,0,0,0.5);
  `;
  
  popup.innerHTML = `
    <h3 style="color: #00c853; margin: 0 0 15px 0;">🎰 Evolution - ${typeLabel} (${numbers.length})</h3>
    <div style="display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 15px; max-height: 200px; overflow-y: auto;">
      ${numbers.slice(0, 100).map(n => `<span style="background: linear-gradient(135deg, #667eea, #764ba2); padding: 4px 10px; border-radius: 6px; font-weight: bold; font-size: 12px;">${n}</span>`).join('')}
      ${numbers.length > 100 ? `<span style="color: #888;">... +${numbers.length - 100} mais</span>` : ''}
    </div>
    <div style="background: #0d0d1a; padding: 10px; border-radius: 8px; margin-bottom: 15px; font-family: monospace; word-break: break-all; font-size: 11px; max-height: 100px; overflow-y: auto;">
      ${numbers.join(' ')}
    </div>
    <button id="extCopyBtn" style="background: linear-gradient(135deg, #00c853, #00e676); color: white; border: none; padding: 12px; border-radius: 8px; width: 100%; font-weight: bold; cursor: pointer; margin-bottom: 8px;">
      📋 Copiar ${numbers.length} Números
    </button>
    <button id="extCloseBtn" style="background: #333; color: white; border: none; padding: 10px; border-radius: 8px; width: 100%; cursor: pointer;">
      ✖ Fechar
    </button>
  `;
  
  document.body.appendChild(popup);
  
  document.getElementById('extCopyBtn').onclick = () => {
    navigator.clipboard.writeText(numbers.join(' '));
    document.getElementById('extCopyBtn').textContent = '✅ Copiado!';
    document.getElementById('extCopyBtn').style.background = '#333';
    setTimeout(() => {
      if (document.getElementById('extCopyBtn')) {
        document.getElementById('extCopyBtn').textContent = `📋 Copiar ${numbers.length} Números`;
        document.getElementById('extCopyBtn').style.background = 'linear-gradient(135deg, #00c853, #00e676)';
      }
    }, 2000);
  };
  
  document.getElementById('extCloseBtn').onclick = () => popup.remove();
}

// Popup de erro
function showErrorPopup(message) {
  removeExistingPopups();
  
  const popup = document.createElement('div');
  popup.id = 'extrator-error';
  popup.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    border: 2px solid #f44336;
    border-radius: 12px;
    padding: 20px;
    z-index: 1000000;
    font-family: Arial, sans-serif;
    color: white;
    max-width: 350px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.5);
  `;
  
  popup.innerHTML = `
    <h3 style="color: #f44336; margin: 0 0 15px 0;">⚠️ Erro</h3>
    <p style="margin: 0 0 15px 0; font-size: 14px;">${message}</p>
    <button id="extErrorCloseBtn" style="background: #333; color: white; border: none; padding: 10px; border-radius: 8px; width: 100%; cursor: pointer;">
      ✖ Fechar
    </button>
  `;
  
  document.body.appendChild(popup);
  document.getElementById('extErrorCloseBtn').onclick = () => popup.remove();
  
  // Auto-fechar após 5 segundos
  setTimeout(() => {
    if (document.getElementById('extrator-error')) {
      document.getElementById('extrator-error').remove();
    }
  }, 5000);
}
