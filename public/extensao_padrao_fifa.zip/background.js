let autoInterval = null;
let lastRawCapture = []; // Armazena a última captura bruta para comparação
let lastUrl = ""; // Armazena a última URL para detectar mudança de mesa

const PROVIDERS = {
  brasileira: {
    selectors: ['[data-testid="single-result"]', '[class*="history-item-value__text"]'],
    extractFunc: (selectors) => {
      const numbers = [];
      for (const selector of selectors) {
        const elements = document.querySelectorAll(selector);
        if (elements.length > 0) {
          elements.forEach(el => {
            const text = el.textContent.trim();
            if (/^\d{1,2}$/.test(text)) {
              const num = parseInt(text);
              if (num >= 0 && num <= 36) numbers.push(text);
            }
          });
          if (numbers.length > 0) break;
        }
      }
      return numbers;
    }
  },
  evolution: {
    selectors: {
      recent: '[data-role="recent-number"] span[class^="value"]',
      stats: '[data-role="statistics"] span[class^="value"]',
      fallback: '[data-role^="number-"]'
    },
    extractFunc: (selectors) => {
      let numbers = [];
      document.querySelectorAll(selectors.recent).forEach(el => {
        const num = el.textContent.trim();
        if (num !== '' && !isNaN(num)) numbers.push(num);
      });
      document.querySelectorAll(selectors.stats).forEach(el => {
        const num = el.textContent.trim();
        if (num !== '' && !isNaN(num)) numbers.push(num);
      });
      return numbers;
    }
  },
  pragmatic: {
    selectors: { primary: '[data-testid="single-result"]', fallback: '[data-bet-code]' },
    extractFunc: (selectors) => {
      let numbers = [];
      document.querySelectorAll(selectors.primary).forEach(el => {
        const num = el.textContent.trim();
        if (num !== '' && !isNaN(num)) numbers.push(num);
      });
      return numbers;
    }
  }
};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'startAutoMode') {
    startMonitoring();
    sendResponse({ status: 'started' });
  } else if (request.action === 'stopAutoMode') {
    stopMonitoring();
    sendResponse({ status: 'stopped' });
  }
});

chrome.storage.local.get(['isAutoMode'], (result) => {
  if (result.isAutoMode) startMonitoring();
});

function startMonitoring() {
  if (autoInterval) clearInterval(autoInterval);
  autoInterval = setInterval(performCapture, 1000);
  addLog('Monitoramento persistente ativo.', 'success');
}

function stopMonitoring() {
  if (autoInterval) clearInterval(autoInterval);
  autoInterval = null;
  addLog('Monitoramento parado.');
}

async function performCapture() {
  const data = await chrome.storage.local.get(['apiUrl', 'userKey', 'provider', 'isAutoMode']);
  if (!data.isAutoMode) {
    stopMonitoring();
    return;
  }

  const providerConfig = PROVIDERS[data.provider || 'brasileira'];

  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length === 0) return;

    const currentUrl = tabs[0].url;

    // FILTRO DE URL: Só processa se parecer uma página de jogo/roleta
    const isRoulettePage = /casino|roulette|game|play|lobby|bet/i.test(currentUrl);
    if (!isRoulettePage) return;

    // DETECÇÃO DE MUDANÇA DE MESA (URL)
    if (lastUrl && currentUrl !== lastUrl) {
      // Só limpa e notifica se a URL realmente mudou para outra página de jogo
      addLog('Mudança de mesa detectada! Limpando banco de dados...', 'info_silent'); // Log sem notificação repetida
      showNotification('Nova mesa detectada. Histórico resetado.');
      await fetch(`${data.apiUrl}/clear/${data.userKey}`, { method: 'POST' });
      lastRawCapture = [];
      lastUrl = currentUrl;
      return; // Interrompe este ciclo para começar limpo no próximo
    }
    lastUrl = currentUrl;

    const result = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id, allFrames: true },
      func: providerConfig.extractFunc,
      args: [providerConfig.selectors]
    });

    let numbers = [];
    for (const frame of result) {
      if (frame.result && frame.result.length > 0) {
        numbers = frame.result;
        break;
      }
    }

    if (numbers.length > 0) {
      // Comparar com a última captura bruta para detectar mudanças reais
      if (JSON.stringify(numbers) !== JSON.stringify(lastRawCapture)) {
        await syncWithDatabase(numbers, data);
        lastRawCapture = [...numbers];
      }
    }
  } catch (err) {
    console.error('Erro no background:', err);
  }
}

async function syncWithDatabase(newNumbers, config) {
  const { apiUrl, userKey } = config;
  try {
    const response = await fetch(`${apiUrl}/data/${userKey}`, {
      method: 'GET',
      mode: 'cors',
      cache: 'no-store',
      headers: { 'Accept': 'application/json', 'Cache-Control': 'no-cache' }
    });
    
    if (!response.ok) return;
    
    const dbData = await response.json();
    let dbNumbers = dbData.numbers || [];

    // Se o banco estiver vazio (limpeza remota), reiniciamos a captura
    if (dbNumbers.length === 0) {
      addLog('Banco de dados limpo remotamente. Reiniciando captura.', 'info');
      await saveToDb(newNumbers.slice(0, 100), config);
      lastRawCapture = []; // Reseta a memória de captura
      return;
    }

    // LÓGICA PARA NÚMEROS REPETIDOS (Ex: 30, 30)
    // Em vez de procurar apenas o primeiro número, procuramos a maior sequência coincidente
    let matchIdx = -1;
    for (let i = 0; i < newNumbers.length; i++) {
      // Tenta encontrar uma fatia da captura que combine com o início do banco
      const slice = newNumbers.slice(i);
      const dbSlice = dbNumbers.slice(0, slice.length);
      
      if (JSON.stringify(slice) === JSON.stringify(dbSlice)) {
        matchIdx = i;
        break;
      }
    }

    if (matchIdx > 0) {
      // Encontrou novos números (mesmo que sejam repetidos!)
      const additions = newNumbers.slice(0, matchIdx);
      let updatedList = [...additions, ...dbNumbers];
      if (updatedList.length > 100) updatedList = updatedList.slice(0, 100);
      
      await saveToDb(updatedList, config);
      addLog(`Adicionados ${additions.length} novos números (incluindo possíveis repetidos).`, 'success');
    } else if (matchIdx === -1) {
      // Sequência não encontrada: Roleta mudou ou pulou muito
      addLog('Sequência alterada. Reiniciando base.', 'error');
      await saveToDb(newNumbers.slice(0, 100), config);
    }
  } catch (err) {
    console.error('Erro sync background:', err);
  }
}

async function saveToDb(numbers, config) {
  const { apiUrl, userKey } = config;
  try {
    await fetch(`${apiUrl}/sync`, {
      method: 'POST',
      mode: 'cors',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_key: userKey, numbers })
    });
    chrome.runtime.sendMessage({ action: 'updateResults', numbers });
  } catch (err) {
    addLog(`Erro Gravação: ${err.message}`, 'error');
  }
}

async function addLog(msg, type = '') {
  const time = new Date().toLocaleTimeString();
  const logEntry = { time, msg, type };
  const result = await chrome.storage.local.get(['logs']);
  let logs = result.logs || [];
  logs.unshift(logEntry);
  if (logs.length > 50) logs = logs.slice(0, 50);
  await chrome.storage.local.set({ logs });
  chrome.runtime.sendMessage({ action: 'newLog', log: logEntry });

  // Disparar notificação para eventos importantes (exceto os marcados como silent)
  if (type === 'success' || type === 'error' || type === 'info') {
    showNotification(msg);
  }
}

function showNotification(message) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'Padrão FIFA - Analisador',
    message: message,
    priority: 2
  });
}
