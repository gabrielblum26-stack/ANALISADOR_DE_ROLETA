document.addEventListener('DOMContentLoaded', async () => {
  // Elementos de Navegação
  const mainScreen = document.getElementById('mainScreen');
  const passwordScreen = document.getElementById('passwordScreen');
  const settingsScreen = document.getElementById('settingsScreen');
  const settingsBtn = document.getElementById('settingsBtn');
  
  // Elementos de Senha
  const configPassword = document.getElementById('configPassword');
  const unlockBtn = document.getElementById('unlockBtn');
  const backFromPassBtn = document.getElementById('backFromPassBtn');

  // Elementos de Configuração
  const apiUrlInput = document.getElementById('apiUrlInput');
  const dbUrlInput = document.getElementById('dbUrlInput');
  const saveConfigBtn = document.getElementById('saveConfigBtn');
  const testConnBtn = document.getElementById('testConnBtn');
  const reconnectBtn = document.getElementById('reconnectBtn');
  const logDisplay = document.getElementById('logDisplay');
  const clearLogsBtn = document.getElementById('clearLogsBtn');
  const backToMainBtn = document.getElementById('backToMainBtn');

  // Elementos Principais
  const providerSelect = document.getElementById('provider');
  const captureBtn = document.getElementById('captureBtn');
  const results = document.getElementById('results');
  const numbersGrid = document.getElementById('numbersGrid');
  const countSpan = document.getElementById('count');
  const copyBtn = document.getElementById('copyBtn');
  const userKeySpan = document.getElementById('userKey');
  const copyKeyBtn = document.getElementById('copyKeyBtn');
  const systemStatus = document.getElementById('systemStatus');

  let extractedNumbers = [];
  const CONFIG_PASSWORD = '6431';

  // Carregar Configurações Iniciais
  const storage = await chrome.storage.local.get(['userKey', 'apiUrl', 'dbUrl', 'isAutoMode', 'logs', 'provider']);
  
  let userKey = storage.userKey || crypto.randomUUID();
  let apiUrl = storage.apiUrl || 'https://padrao-fifa-backend.vercel.app';
  let dbUrl = storage.dbUrl || 'postgresql://neondb_owner:npg_n7KBqfc5uTHl@ep-ancient-poetry-ahwyd85d-pooler.c-3.us-east-1.aws.neon.tech/neondb?sslmode=require';
  let isAutoMode = storage.isAutoMode || false;
  let logs = storage.logs || [];
  let provider = storage.provider || 'brasileira';

  await chrome.storage.local.set({ userKey, apiUrl, dbUrl, provider });
  
  userKeySpan.textContent = userKey;
  apiUrlInput.value = apiUrl;
  dbUrlInput.value = dbUrl;
  providerSelect.value = provider;

  // Renderizar logs salvos
  logs.forEach(log => renderLog(log));

  if (isAutoMode) {
    updateUIActive();
  }

  // Navegação
  settingsBtn.addEventListener('click', () => {
    mainScreen.classList.add('hidden');
    passwordScreen.classList.remove('hidden');
    configPassword.value = '';
    configPassword.focus();
  });

  unlockBtn.addEventListener('click', () => {
    if (configPassword.value === CONFIG_PASSWORD) {
      passwordScreen.classList.add('hidden');
      settingsScreen.classList.remove('hidden');
    } else {
      alert('Senha incorreta!');
    }
  });

  backFromPassBtn.addEventListener('click', () => {
    passwordScreen.classList.add('hidden');
    mainScreen.classList.remove('hidden');
  });

  backToMainBtn.addEventListener('click', () => {
    settingsScreen.classList.add('hidden');
    mainScreen.classList.remove('hidden');
  });

  // Salvar Configurações
  saveConfigBtn.addEventListener('click', async () => {
    apiUrl = apiUrlInput.value.trim().replace(/\/$/, '');
    dbUrl = dbUrlInput.value.trim();
    provider = providerSelect.value;
    await chrome.storage.local.set({ apiUrl, dbUrl, provider });
    alert('Configurações salvas!');
  });

  providerSelect.addEventListener('change', async () => {
    await chrome.storage.local.set({ provider: providerSelect.value });
  });

  // Testar Conexão
  testConnBtn.addEventListener('click', async () => {
    try {
      const res = await fetch(`${apiUrl}/`, { mode: 'cors' });
      if (res.ok) alert('API Online!');
      else alert('Erro na API: ' + res.status);
    } catch (err) {
      alert('Falha na conexão: ' + err.message);
    }
  });

  clearLogsBtn.addEventListener('click', async () => {
    logDisplay.innerHTML = '';
    await chrome.storage.local.set({ logs: [] });
  });

  // Ativar/Desativar Sistema
  captureBtn.addEventListener('click', async () => {
    if (!isAutoMode) {
      isAutoMode = true;
      await chrome.storage.local.set({ isAutoMode: true });
      chrome.runtime.sendMessage({ action: 'startAutoMode' });
      updateUIActive();
    } else {
      isAutoMode = false;
      await chrome.storage.local.set({ isAutoMode: false });
      chrome.runtime.sendMessage({ action: 'stopAutoMode' });
      updateUIInactive();
    }
  });

  function updateUIActive() {
    captureBtn.textContent = '🟢 SISTEMA ATIVO';
    captureBtn.classList.add('active-system');
    systemStatus.textContent = 'Monitorando em segundo plano...';
    systemStatus.classList.remove('hidden');
  }

  function updateUIInactive() {
    captureBtn.textContent = '🚀 ATIVAR SISTEMA';
    captureBtn.classList.remove('active-system');
    systemStatus.classList.add('hidden');
  }

  // Listeners para atualizações do Background
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'newLog') {
      renderLog(message.log);
    } else if (message.action === 'updateResults') {
      displayResults(message.numbers);
    }
  });

  function renderLog(log) {
    const entry = document.createElement('div');
    entry.className = `log-entry ${log.type ? 'log-' + log.type : ''}`;
    entry.innerHTML = `<span class="log-time">[${log.time}]</span> ${log.msg}`;
    logDisplay.prepend(entry);
  }

  function displayResults(numbers) {
    extractedNumbers = numbers;
    countSpan.textContent = numbers.length;
    numbersGrid.innerHTML = numbers.map(n => `<span class="number-item">${n}</span>`).join('');
    results.classList.remove('hidden');
  }

  copyKeyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(userKey);
    copyKeyBtn.textContent = 'Copiado!';
    setTimeout(() => copyKeyBtn.textContent = 'Copiar', 2000);
  });

  copyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(extractedNumbers.join(' '));
    copyBtn.textContent = '✅ Copiado!';
    setTimeout(() => copyBtn.textContent = '📋 Copiar Tudo', 2000);
  });
});
